﻿UVLM Upload Bundle Manifest
==========================

Repo: https://github.com/pdxvoiceteacher/CoherenceLattice

Purpose:
- Fast onboarding for Echo iterations
- Reproducible green (tests + CI)
- Telemetry cognition loop (telemetry -> state_estimate -> policy -> proposal)
- Plasticity governance (approved proposals + receipts + rollback)

Key commands (Windows):
  powershell -ExecutionPolicy Bypass -File scripts\dev_bootstrap.ps1
  powershell -ExecutionPolicy Bypass -File scripts\patch_ci.ps1
  powershell -ExecutionPolicy Bypass -File scripts\new_receipt.ps1
  powershell -ExecutionPolicy Bypass -File scripts\make_uvlm_bundle.ps1

